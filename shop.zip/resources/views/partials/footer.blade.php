<footer>
    <div class="footer-content container">
        <div class="made-with justify-content-center">Made with <i class="fa fa-heart heart"></i> by VIRENDRA AREKAR</div>
        {{ menu('footer', 'partials.menus.footer') }}
    </div> <!-- end footer-content -->
</footer>
