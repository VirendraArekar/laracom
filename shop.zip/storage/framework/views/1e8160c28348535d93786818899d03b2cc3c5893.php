<footer>
    <div class="footer-content container">
        <div class="made-with justify-content-center"><p class="text-center">Made with <i class="fa fa-heart heart"></i> by Virendra Arekar</p></div>
        <?php echo e(menu('footer', 'partials.menus.footer')); ?>

    </div> <!-- end footer-content -->
</footer>
<?php /**PATH /var/www/html/shop/resources/views/partials/footer.blade.php ENDPATH**/ ?>